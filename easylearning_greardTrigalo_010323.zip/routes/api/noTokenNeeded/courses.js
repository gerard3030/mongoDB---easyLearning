const express = require("express");
const router = express.Router();

const coursesModel = require("../../../model/courses.model");
const coursesValidation = require("../../../validation/courses.validation");
const ResponseError = require("../../../module/ResponseError");

// DNU - TESTING
// router.get("/category/:category", async (req,res)=>{
//     try {
//         const categoryFromUser = req.params;
//         const validateUserReq = await coursesValidation.showCategorySchemaValidation(categoryFromUser);
//         if (validateUserReq) {
//             const courseByiled =await  coursesModel.showCourseByCategory(validateUserReq.category);
//             if (courseByiled) {
//                 res.json(courseByiled)
//             } else {
//                 res.json("no courses for this filed")
//             }
//         } else {
//             throw new ResponseError ("reauest error", ["invalid data"])
//         }

//     } catch(err){
//         res.json({err, me:"test - by ctegory"})
//     }
// })

// show products 10 for page
router.get("/:page", async (req, res) => {
  try {
    const userReq = req.params;
    const validatedValue = await coursesValidation.showPageSchemaValidation(
      userReq
    );
    if (!validatedValue) {
      throw new ResponseError("reauest error", ["invalid data"]);
    } else {
      const showItems = await coursesModel.showCourses(validatedValue.page);
      res.json(showItems);
    }
  } catch (err) {
    res.status(400).json({ err });
  }
});

module.exports = router;
