const express = require("express");
const router = express.Router();

const coursesModel = require("../../../../model/courses.model");
const coursesValidation = require("../../../../validation/courses.validation");
const ResponseError = require("../../../../module/ResponseError");

// add course

router.post("/addCourse", async (req, res) => {
  try {
    const adimData = req.body;
    const validatedData = await coursesValidation.courseSchemaValidation(
      adimData
    );
    const dataToDB = await coursesModel.createNewCourse(
      validatedData,
      req.passId
    );
    if (!dataToDB) {
      throw new ResponseError("reauest error", ["invalid data"]);
    }
    res.json({
      msg: "course added to DB",
    });
  } catch (err) {
    res.status(400).json({ err });
  }
});

// edit course

router.patch("/editCourse", async (req, res) => {
  try {
    const dataFromAdmin = req.body;
    const validatedData = await coursesValidation.editProductSchemaValication(
      dataFromAdmin
    );
    const verifyCourseID = await coursesModel.findCourseByID(
      validatedData.productID
    );
    if (!verifyCourseID) {
      throw new ResponseError("reauest error", ["course do not exist"]);
    }
    const updatedData = await coursesModel.updateCourse(
      validatedData.productID,
      validatedData.filedToUpdate,
      validatedData.dataUpdated
    );
    res.json({
      msg: "data updated",
    });
  } catch (err) {
    res.status(400).json({ err });
  }
});

// delete course

router.delete("/deleteCourse", async (req, res) => {
  try {
    const adminData = req.body;
    const verifyData = await coursesValidation.deleteCourseSchemaValidation(
      adminData
    );
    if (!verifyData) {
      throw new ResponseError("reauest error", ["course do not exist"]);
    }
    const courseExsist = await coursesModel.findCourseByID(
      verifyData.productID
    );
    if (!courseExsist) {
      throw new ResponseError("reauest error", ["course do not exist"]);
    }
    const deleteCourse = coursesModel.deleteCourse(courseExsist._id);
    res.json({
      msg: "Course Deleted",
    });
  } catch (err) {
    res.status(400).json({ err });
  }
});

module.exports = router;
