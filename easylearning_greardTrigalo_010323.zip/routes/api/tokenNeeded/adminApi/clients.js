const express = require("express");
const router = express.Router();

const usersModel = require("../../../../model/users.model");
const authValidation = require("../../../../validation/auth.validation");
const ResponseError = require("../../../../module/ResponseError");
const bcrypt = require("../../../../config/bcrypt");
const jwt = require("../../../../config/jwt");

// unblock user

router.patch("/unblock", async (req, res) => {
  try {
    const dataFromUser = req.body;
    const validatedUserInfo = await authValidation.validateUnblockSchema(
      dataFromUser
    );
    const userInfoFromDB = await usersModel.findUserByEmail(
      validatedUserInfo.email
    );
    if (userInfoFromDB && userInfoFromDB.isAdmin === true) {
      const verifyPassword = await bcrypt.compareHash(
        validatedUserInfo.password,
        userInfoFromDB.password
      );
      if (verifyPassword) {
        const userToUnlock = await usersModel.findUserByEmail(
          validatedUserInfo.userUnblockEmail
        );
        if (userToUnlock) {
          await usersModel.unBlockAccount(userToUnlock._id);
        } else {
          throw new ResponseError("no data: ", [
            "user to unlock cant be found",
          ]);
        }
      } else {
        throw new ResponseError("authication erorr: ", [
          "admin password not correct",
        ]);
      }
    } else {
      throw new ResponseError("authication erorr: ", [
        "user dosent exsist or admin",
      ]);
    }
    res.json({
      msg: "user unblocked",
    });
  } catch (err) {
    res.status(400).json({ err });
  }
});

module.exports = router;
