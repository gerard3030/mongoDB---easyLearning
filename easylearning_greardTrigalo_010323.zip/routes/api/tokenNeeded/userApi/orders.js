const express = require("express");
const router = express.Router();

const ordersModule = require("../../../../model/orders.model");
const orderValidation = require("../../../../validation/orders.validation");

const couresModel = require("../../../../model/courses.model");
const usersModel = require("../../../../model/users.model");

const ResponseError = require("../../../../module/ResponseError");
const bcrypt = require("../../../../config/bcrypt");
// const validateSchema = require("../../validation/schema.validation");
const jwt = require("../../../../config/jwt");

router.post("/order", async (req, res) => {
  try {
    const userOrderData = req.body;
    const userID = req.passId;
    const findUserByToken = await usersModel.findByID(userID);
    // compare user token with rues id for addtinal securety
    const verifyData = await orderValidation.ordersSchemaValidation(
      userOrderData
    );
    if (!verifyData) {
      throw new ResponseError("reauest error", ["invalid data"]);
    } else {
      if (userID != verifyData.userID && findUserByToken.isAdmin == false) {
        throw new ResponseError("reauest error", [
          "user ID do not match user Token! haking! ",
        ]);
      }
      // chck if course avalible
      const courseAvalible = await couresModel.findCourseByID(
        verifyData.courseID
      );
      if (!courseAvalible) {
        throw new ResponseError("no data: ", [
          `Course can't be found - Pleas contact Office`,
        ]);
      } else {
        const hasOrder = await ordersModule.findUserOrder(userOrderData.userID);
        if (hasOrder.length > 0) {
          throw new ResponseError("reauest error", [
            "user alredy placed order",
          ]);
        } else {
          const findUser = await usersModel.findByID(userOrderData.userID);
          // check  hardcopy stock if needed
          if (verifyData.copysNeeded) {
            if (
              verifyData.copysNeeded > courseAvalible.printCopy.copyStokAmount
            ) {
              throw new ResponseError("reauest error", [
                `${courseAvalible.printCopy.copyStokAmount} has left in stock, please contact the ofiice for more info`,
              ]);
            }
          }
          let orderInfo = {
            courseID: courseAvalible.id,
            userID: findUser.id,
            userName: findUser.fisrtName,
            copysNeeded: verifyData.copysNeeded,
            privetLession: verifyData.privetLession,
            finalPayment: await ordersModule.calcOrder(
              courseAvalible.price.coursePrice,
              courseAvalible.price.privetPrice,
              verifyData.privetLession,
              courseAvalible.printCopy.copyPrice,
              verifyData.copysNeeded
            ),
          };
          if (verifyData.copysNeeded) {
            await couresModel.updatePrintedQ(
              courseAvalible.id,
              courseAvalible.printCopy.copyStokAmount - verifyData.copysNeeded
            );
            const updatedCourse = await couresModel.findCourseByID(
              courseAvalible.id
            );
            if (updatedCourse.printCopy.copyStokAmount <= 0) {
              await couresModel.printedNotInStock(courseAvalible.id, false);
            }
          }
          // complate order
          const placeNewOrder = await ordersModule.createNewOrder(orderInfo);
          res.json({
            msg: " order placed!",
            toUser: `Hey ${placeNewOrder.userName}, your order for ${courseAvalible.couseName} online has been placed.`,
          });
        }
      }
    }
  } catch (err) {
    res.status(400).json({ err });
  }
});

module.exports = router;
