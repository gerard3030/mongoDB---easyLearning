const express = require("express");
const router = express.Router();

const usersModel = require("../../../../model/users.model");
const authValidation = require("../../../../validation/auth.validation");
const ResponseError = require("../../../../module/ResponseError");
const bcrypt = require("../../../../config/bcrypt");
// const validateSchema = require("../../validation/schema.validation");
const jwt = require("../../../../config/jwt");

// user or admin change user password
router.patch("/reset", async (req, res) => {
  try {
    const userID = req.passId;
    const informationForUser = req.body;
    const verifyData = await authValidation.validateResetPasswordSchemaNew(
      informationForUser
    );
    if (!verifyData) {
      throw new ResponseError("db error: ", ["data Invalid"]);
    }
    const findUserFromDB = await usersModel.findUserByEmail(verifyData.email);
    const isUserAdimin = await usersModel.findByID(userID);
    // check if user is account owner or admin

    if (findUserFromDB._id == userID || isUserAdimin.isAdmin === true) {
      const hasedPass = await bcrypt.createHash(verifyData.newPassword);
      const resetPassword = await usersModel.updateUserPassword(
        findUserFromDB._id,
        hasedPass
      );
    } else {
      throw new ResponseError("db error: ", [
        "only adim or account owner can update",
      ]);
    }
    res.json({
      msg: "password updated",
    });
  } catch (err) {
    res.status(400).json({ err });
  }
});

module.exports = router;
