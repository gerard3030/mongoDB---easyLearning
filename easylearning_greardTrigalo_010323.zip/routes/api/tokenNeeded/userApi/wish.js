const express = require("express");
const router = express.Router();

const wishModule = require("../../../../model/wish.model");
const wishValidation = require("../../../../validation/wish.validation");

const couresModel = require("../../../../model/courses.model");
const usersModel = require("../../../../model/users.model");

const ResponseError = require("../../../../module/ResponseError");
const bcrypt = require("../../../../config/bcrypt");
const jwt = require("../../../../config/jwt");

router.post("/wish", async (req, res) => {
  try {
    const userID = req.passId;
    const verifyUserData = req.body;
    const validateUserInfo = await wishValidation.wishListSchemaValidation(
      verifyUserData
    );
    if (!validateUserInfo) {
      throw new ResponseError("data error: ", ["enter correct data"]);
    } else {
      const courseAvalible = await couresModel.findCourseByID(
        validateUserInfo.productID
      );
      if (!courseAvalible) {
        throw new ResponseError("data error: ", ["we dont have this couse "]);
      } else {
        const userHasList = await wishModule.checkForUserList(userID);
        if (userHasList.length <= 0) {
          const createNewList = await wishModule.createNewList(
            validateUserInfo,
            userID
          );
          res.json({
            msg: `your first wishlish has been created with course ${courseAvalible.couseName}, ID ${courseAvalible._id}`,
          });
        } else {
          const currentList = userHasList[0];
          let previousItems = currentList.allCoursesInList;
          const additionalCourse = courseAvalible._id;
          const allCourses = [...previousItems, additionalCourse];
          const checkIfexist = previousItems.includes(additionalCourse);
          if (checkIfexist) {
            throw new ResponseError("data error: ", [
              "Course alrdy in your list ",
            ]);
          } else {
            const updateList = await wishModule.updateList(
              currentList.id,
              allCourses
            );
            res.json({ msg: "course added to wishlist" });
          }
        }
      }
    }
  } catch (err) {
    res.status(400).json({ err });
  }
});

module.exports = router;
