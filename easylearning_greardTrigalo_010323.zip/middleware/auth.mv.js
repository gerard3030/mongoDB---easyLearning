const jwt = require("../config/jwt");
const userMod = require("../model/users.model");

module.exports = async (req, res, next) => {
  try {
    const payload = await jwt.verifyToken(req.headers["token"]);
    console.log("payload: ", payload);
    req.passId = payload.id;
    const userFromDB = await userMod.findByID(req.passId);
    next();
  } catch (err) {
    console.log(err);
    res.status(401).json(err);
  }
};
