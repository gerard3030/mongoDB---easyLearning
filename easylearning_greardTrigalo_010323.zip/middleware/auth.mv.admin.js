const jwt = require("../config/jwt");
const userMod = require("../model/users.model");
const ResponseError = require("../module/ResponseError");

module.exports = async (req, res, next) => {
  try {
    const payload = await jwt.verifyToken(req.headers["token"]);
    console.log("payload: ", payload);
    req.passId = payload.id;
    const userFromDB = await userMod.findByID(req.passId);
    if (userFromDB.isAdmin === false) {
      throw new ResponseError("haking error", ["user is not an admin"]);
    } else {
      next();
    }
  } catch (err) {
    console.log(err);
    res.status(401).json(err);
  }
};
