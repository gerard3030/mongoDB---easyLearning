const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ordersSchema = new Schema({
  courseID: { type: String, required: true },
  courseName: { type: String },
  userID: { type: String },
  userName: { type: String },
  copysNeeded: { type: Number },
  privetLession: { type: Number },
  finalPayment: { type: Number },
});

const Order = mongoose.model("orders", ordersSchema);

const createNewOrder = (userInput) => {
  const newOrder = new Order(userInput);
  return newOrder.save();
};

const findUserOrder = (userID) => {
  const usereistingOder = Order.find({ userID: userID });
  return usereistingOder;
};

const calcOrder = (
  coursePrice,
  privetPrice = 0,
  privetQ = 0,
  bookPrice = 0,
  bookQ = 0
) => {
  const total = bookPrice * bookQ + privetPrice * privetQ + coursePrice;
  return total;
};

module.exports = {
  createNewOrder,
  findUserOrder,
  calcOrder,
};
