const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const wishListSchema = new Schema({
  productID: { type: String, required: true },
  userID: { type: String },
  allCoursesInList: [String],
});

const WishList = mongoose.model("wishList", wishListSchema);

const createNewList = (listData, id) => {
  const newList = new WishList(listData);
  newList.userID = id;
  newList.allCoursesInList = [listData.productID];
  return newList.save();
};

const checkForUserList = (_id) => {
  const hasList = WishList.find({ userID: _id });
  return hasList;
};

const updateList = (id, newData) => {
  return WishList.findByIdAndUpdate(id, { allCoursesInList: newData })
    .then((err, data) => {
      if (!err) {
        data;
      } else {
        throw err;
      }
    })
    .catch((error) => {
      error;
    });
};

module.exports = {
  createNewList,
  checkForUserList,
  updateList,
};
