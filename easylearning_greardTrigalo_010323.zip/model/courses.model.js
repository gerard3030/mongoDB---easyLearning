const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const coruseSchema = new Schema({
  couseName: { type: String, required: true },
  category: { type: String },
  lecturer: { type: String },
  description: { type: String },
  price: {
    coursePrice: { type: Number, required: true, default: 30 },
    privetPrice: { type: Number, default: 30 },
  },
  totalHours: { type: Number },
  isPrivetSeasson: { type: Boolean, default: false },
  printCopy: {
    isPrintAvalible: { type: Boolean, default: true },
    copyStokAmount: { type: Number, default: 100 },
    copyPrice: { type: Number, default: 15 },
  },
  addedBy: { type: String },
});

const Courses = mongoose.model("courses", coruseSchema);

const createNewCourse = (courseData, adminID) => {
  const newCourse = new Courses(courseData);
  newCourse.addedBy = adminID;
  return newCourse.save();
};

const showCourses = (pageNum = 1, itemPerPage = 10) => {
  const allCourses = Courses.find()
    .skip((pageNum - 1) * itemPerPage)
    .limit(itemPerPage)
    .select("couseName");
  return allCourses;
};

// error HERE!
const showCourseByCategory = (category, pageNum = 1, itemPerPage = 4) => {
  const courseByFiled = Courses.find({ category: category })
    .skip((pageNum - 1) * itemPerPage)
    .limit(itemPerPage)
    .select("couseName");
  return courseByFiled;
};

const updateCourse = (_id, filed, dataUpdated) => {
  return Courses.findByIdAndUpdate({ _id: _id }, { [filed]: dataUpdated });
};

const deleteCourse = (courseID) => Courses.findByIdAndDelete(courseID);

const updatePrintedQ = (id, newQ) => {
  return Courses.findByIdAndUpdate(id, { "printCopy.copyStokAmount": newQ })
    .then((err, data) => {
      if (!err) {
        data;
      } else {
        throw err;
      }
    })
    .catch((error) => {
      error;
    });
};

const printedNotInStock = (id, newQ) => {
  return Courses.findByIdAndUpdate(id, { "printCopy.isPrintAvalible": newQ })
    .then((err, data) => {
      if (!err) {
        data;
      } else {
        throw err;
      }
    })
    .catch((error) => {
      error;
    });
};

const findCourseByID = (_id) =>
  Courses.findById(_id)
    .then((data) => data)
    .catch((err) => err);

module.exports = {
  createNewCourse,
  showCourses,
  showCourseByCategory,
  updateCourse,
  deleteCourse,
  findCourseByID,
  updatePrintedQ,
  printedNotInStock,
};
