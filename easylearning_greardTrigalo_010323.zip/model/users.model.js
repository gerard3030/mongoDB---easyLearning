const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const usersSchema = new Schema({
  fisrtName: { type: String, required: true },
  lastName: { type: String },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  address: {
    country: { type: String },
    city: { type: String },
    street: { type: String },
    houseNumber: { type: String },
    zip: { type: String },
  },
  phone: { type: Number, unique: true },
  isAdmin: { type: Boolean, default: false },
  accountSecurety: {
    failedAttempts: { type: Number, default: 0 },
    isBlocked: { type: Boolean, default: false },
    lastAttempt: { type: Date, default: Date.now },
  },
});

const Users = mongoose.model("users", usersSchema);

const createNewUser = (userData) => {
  const newUser = new Users(userData);
  return newUser.save();
};

const findUserByEmail = (email) => {
  return Users.findOne({ email });
};

const blockAccount = (_id) => {
  return Users.findByIdAndUpdate(_id, {
    "accountSecurety.isBlocked": true,
    "accountSecurety.failedAttempts": 0,
  });
};

const updateUserAttempt = (_id, currentAttemp) => {
  return Users.findByIdAndUpdate(_id, {
    "accountSecurety.failedAttempts": currentAttemp + 1,
  });
};

const unBlockAccount = (_id) => {
  return Users.findByIdAndUpdate(_id, {
    "accountSecurety.isBlocked": false,
    "accountSecurety.failedAttempts": 0,
  });
};


const updateUserPassword = (id, newPassword) => {
  return Users.findByIdAndUpdate(id, { password: newPassword });
};

const findByID = (id) => Users.findById(id);

module.exports = {
  createNewUser,
  findUserByEmail,
  updateUserPassword,
  blockAccount,
  unBlockAccount,
  findByID,
  updateUserAttempt,
};
