const Joi = require("joi");
const validate = require("./schema.validation");

const registerSchema = Joi.object({
  fisrtName: Joi.string()
    .min(3)
    .max(200)
    .alphanum()
    .required()
    .trim()
    .messages({ "string.base": "first name Mssing / Invalid filed" }),
  lastName: Joi.string()
    .min(3)
    .max(200)
    .alphanum()
    .required()
    .trim()
    .messages({ "string.base": "salst name Mssing / Invalid filed" }),
  email: Joi.string()
    .min(10)
    .max(200)
    .email()
    .required()
    .trim()
    .messages({ "string.email": "Invalid Email" }),
  password: Joi.string()
    .regex(
      new RegExp(
        "^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*()+-_=]).{3,255}"
      )
    )
    .required()
    .messages({
      "string.pattern.base":
        "Password must contai uper+lower case letter, number and a symbl",
    }),
  phone: Joi.string()
    .min(10)
    .max(14)
    .messages({ "string.base": "phone Mssing / Invalid filed" }),
  address: {
    country: Joi.string()
      .min(3)
      .max(200)
      .messages({ "string.base": "country Mssing / Invalid filed" }),
    city: Joi.string()
      .min(3)
      .max(200)
      .messages({ "string.base": "city Mssing / Invalid filed" }),
    street: Joi.string()
      .min(3)
      .max(200)
      .messages({ "string.base": "street Mssing / Invalid filed" }),
    houseNumber: Joi.string()
      .min(1)
      .max(200)
      .messages({ "string.base": "houseNumber Mssing / Invalid filed" }),
    zip: Joi.string()
      .min(3)
      .max(200)
      .messages({ "string.base": "zip Mssing / Invalid filed" }),
  },
});

const validateRegisterSchema = (userInput) =>
  validate(userInput, registerSchema);

const loginSchema = Joi.object({
  email: Joi.string()
    .min(10)
    .max(200)
    .email()
    .required()
    .trim()
    .messages({ "string.email": "Invalid Email" }),
  password: Joi.string()
    .regex(
      new RegExp(
        "^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*()+-_=]).{3,255}"
      )
    )
    .required()
    .messages({
      "string.pattern.base":
        "Password must contai uper+lower case letter, number and a symbl",
    }),
});

const validateLoginSchema = (userInput) => validate(userInput, loginSchema);

const resetPasswordSchema = Joi.object({
  email: Joi.string()
    .min(10)
    .max(200)
    .email()
    .required()
    .trim()
    .messages({ "string.email": "Invalid Email" }),
  newPassword: Joi.string()
    .regex(
      new RegExp(
        "^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*()+-_=]).{3,255}"
      )
    )
    .required()
    .messages({
      "string.pattern.base":
        "Password must contai uper+lower case letter, number and a symbl",
    }),
  phone: Joi.string()
    .min(9)
    .max(15)
    .messages({ "string.base": "phone Mssing / Invalid filed" }),
});

const validateResetPasswordSchema = (userInput) =>
  validate(userInput, resetPasswordSchema);

const resetPasswordSchemaNew = Joi.object({
  email: Joi.string()
    .min(10)
    .max(200)
    .email()
    .required()
    .trim()
    .messages({ "string.email": "Invalid Email" }),
  newPassword: Joi.string()
    .regex(
      new RegExp(
        "^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*()+-_=]).{3,255}"
      )
    )
    .required()
    .messages({
      "string.pattern.base":
        "Password must contai uper+lower case letter, number and a symbl",
    }),
  phone: Joi.string()
    .min(9)
    .max(15)
    .messages({ "string.base": "phone Mssing / Invalid filed" }),
});

const validateResetPasswordSchemaNew = (userInput) =>
  validate(userInput, resetPasswordSchemaNew);

const unblock = Joi.object({
  email: Joi.string()
    .min(10)
    .max(200)
    .email()
    .required()
    .trim()
    .messages({ "string.email": "Invalid Email" }),
  password: Joi.string()
    .regex(
      new RegExp(
        "^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&*()+-_=]).{3,255}"
      )
    )
    .required()
    .messages({
      "string.pattern.base":
        "Password must contai uper+lower case letter, number and a symbl",
    }),
  userUnblockEmail: Joi.string()
    .min(10)
    .max(200)
    .email()
    .required()
    .trim()
    .messages({ "string.email": "Invalid Email" }),
});

const validateUnblockSchema = (userInput) => validate(userInput, unblock);

module.exports = {
  validateRegisterSchema,
  validateLoginSchema,
  validateResetPasswordSchema,
  validateUnblockSchema,
  validateResetPasswordSchemaNew,
};
