const Joi = require("joi");
const validate = require("./schema.validation");

const courseSchema = Joi.object({
  couseName: Joi.string()
    .min(3)
    .max(30)
    .required()
    .trim()
    .messages({ "string.base": "course name Mssing / Invalid filed" }),
  category: Joi.string()
    .min(3)
    .max(30)
    .trim()
    .messages({ "string.base": "category Mssing / Invalid filed" }),
  lecturer: Joi.string()
    .min(3)
    .max(30)
    .trim()
    .messages({ "string.base": "lecturer name Mssing / Invalid filed" }),
  description: Joi.string()
    .min(3)
    .max(300)
    .trim()
    .messages({ "string.base": "description Mssing / Invalid filed" }),
  price: {
    coursePrice: Joi.number()
      .integer()
      .min(15)
      .required()
      .messages({ "string.base": "price Mssing / Invalid filed" }),
    privetPrice: Joi.number()
      .integer()
      .min(15)
      .messages({ "string.base": "price Mssing / Invalid filed" }),
  },
  totalHours: Joi.number()
    .integer()
    .min(15)
    .messages({ "string.base": "PrivetSeasson Mssing / Invalid filed" }),
  isPrivetSeasson: Joi.boolean().messages({
    "string.base": "PrivetSeasson Mssing / Invalid filed",
  }),
  printCopy: {
    isPrintAvalible: Joi.boolean().messages({
      "string.base": "printCopy Mssing / Invalid filed",
    }),
    copyStokAmount: Joi.number()
      .integer()
      .min(15)
      .messages({ "string.base": "printCopy Mssing / Invalid filed" }),
  },
  addedBy: Joi.string(),
});

const courseSchemaValidation = (adimInput) => validate(adimInput, courseSchema);

const showPageSchema = Joi.object({
  page: Joi.number().integer(),
});

const showPageSchemaValidation = (userInput) =>
  validate(userInput, showPageSchema);

const showCategorySchema = Joi.object({
  category: Joi.string()
    .alphanum()
    .min(3)
    .max(25)
    .messages({ "string.base": "category Mssing / Invalid filed" }),
});

const showCategorySchemaValidation = (userInput) =>
  validate(userInput, showCategorySchema);

const editProductSchema = Joi.object({
  productID: Joi.string()
    .required()
    .messages({ "string.base": "productID name Mssing / Invalid filed" }),
  filedToUpdate: Joi.string()
    .required()
    .messages({ "string.base": "filed to update Mssing / Invalid filed" }),
  dataUpdated: Joi.string()
    .required()
    .messages({ "string.base": "data Updated filed Mssing / Invalid filed" }),
});

const editProductSchemaValication = (adminInput) =>
  validate(adminInput, editProductSchema);

const deleteCourseSchema = Joi.object({
  productID: Joi.string()
    .required()
    .max(24)
    .messages({ "string.base": "productID Mssing / Invalid filed" }),
});

const deleteCourseSchemaValidation = (adminInput) =>
  validate(adminInput, deleteCourseSchema);

module.exports = {
  courseSchemaValidation,
  showPageSchemaValidation,
  showCategorySchemaValidation,
  editProductSchemaValication,
  deleteCourseSchemaValidation,
};
