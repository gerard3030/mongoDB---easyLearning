const Joi = require("joi");
const validate = require("./schema.validation");

const wishListSchema = Joi.object({
  productID: Joi.string()
    .min(24)
    .max(200)
    .alphanum()
    .required()
    .trim()
    .messages({ "string.base": "Mssing / Invalid filed" }),
});
const wishListSchemaValidation = (userInput) =>
  validate(userInput, wishListSchema);

module.exports = {
  wishListSchemaValidation,
};
